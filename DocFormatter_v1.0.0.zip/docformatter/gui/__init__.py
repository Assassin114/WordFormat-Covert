"""
gui - PyQt6 图形界面模块
"""

from .main_window import MainWindow

__all__ = ['MainWindow']
